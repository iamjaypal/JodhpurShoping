import React from 'react';
import '../styles/Banner.css'
function Banner() {
    return (
        <>
            <div className="banner-container">
                <div className="banner-wrapper">
                    <div className="banner-text">ᕼᗩᑭᑭY ᖴᗩᑕEᔕ ᑕOᗰE ᖴᖇOᗰ TᕼE ᑭIᘔᘔᗩ</div>
                    <div className="banner-box"></div>
                </div>
            </div>
        </>
    );
}

export default Banner;