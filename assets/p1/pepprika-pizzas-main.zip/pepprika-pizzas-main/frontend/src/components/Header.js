import React from 'react'
import NavbarComponent from './Navbar';
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';

function Header() {
    return (
        <>
            <NavbarComponent />
        </>
    )
}

export default Header;